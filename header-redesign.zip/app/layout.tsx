import Header from "@/components/Header"
import "@/styles/globals.css"

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Header />
        <main className="pt-16 sm:pt-20">{children}</main>
      </body>
    </html>
  )
}



import './globals.css'