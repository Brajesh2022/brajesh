import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X, ChevronDown } from "lucide-react"

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? "bg-white shadow-md" : "bg-transparent"}`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-2">
              <div className="relative w-10 h-10 sm:w-12 sm:h-12 overflow-hidden rounded-full bg-white shadow-lg">
                <Image
                  src="https://i.postimg.cc/SRF9rhfv/logo-1.png"
                  alt="DPS Keoti Logo"
                  layout="fill"
                  objectFit="contain"
                  className="p-1"
                />
              </div>
              <span className={`font-bold text-lg sm:text-xl ${isScrolled ? "text-gray-800" : "text-white"}`}>
                DPS Keoti
              </span>
            </Link>
          </div>

          <nav className="hidden md:flex space-x-8">
            <NavLink href="/" label="Home" isScrolled={isScrolled} />
            <NavLink href="/about" label="About Us" isScrolled={isScrolled} />
            <DropdownLink
              label="Gallery"
              items={[
                { href: "/gallery/photos", label: "Photo Gallery" },
                { href: "/gallery/videos", label: "Video Gallery" },
              ]}
              isScrolled={isScrolled}
            />
            <NavLink href="/contact" label="Contact" isScrolled={isScrolled} />
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <Link href="/admissions" className="btn btn-primary">
              Admissions Open
            </Link>
            <Link href="/login" className={`btn ${isScrolled ? "btn-outline-dark" : "btn-outline-light"}`}>
              Login
            </Link>
          </div>

          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className={`p-2 rounded-md ${isScrolled ? "text-gray-800" : "text-white"}`}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`md:hidden ${isMenuOpen ? "block" : "hidden"}`}>
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
          <MobileNavLink href="/" label="Home" />
          <MobileNavLink href="/about" label="About Us" />
          <MobileDropdownLink
            label="Gallery"
            items={[
              { href: "/gallery/photos", label: "Photo Gallery" },
              { href: "/gallery/videos", label: "Video Gallery" },
            ]}
          />
          <MobileNavLink href="/contact" label="Contact" />
        </div>
        <div className="pt-4 pb-3 border-t border-gray-200">
          <div className="flex items-center px-5">
            <Link href="/admissions" className="btn btn-primary w-full mb-2">
              Admissions Open
            </Link>
          </div>
          <div className="flex items-center px-5">
            <Link href="/login" className="btn btn-outline-dark w-full">
              Login
            </Link>
          </div>
        </div>
      </div>
    </header>
  )
}

const NavLink = ({ href, label, isScrolled }) => (
  <Link
    href={href}
    className={`text-sm font-medium ${isScrolled ? "text-gray-800" : "text-white"} hover:text-green-500 transition-colors duration-200`}
  >
    {label}
  </Link>
)

const DropdownLink = ({ label, items, isScrolled }) => {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="relative" onMouseEnter={() => setIsOpen(true)} onMouseLeave={() => setIsOpen(false)}>
      <button
        className={`flex items-center text-sm font-medium ${isScrolled ? "text-gray-800" : "text-white"} hover:text-green-500 transition-colors duration-200`}
      >
        {label}
        <ChevronDown size={16} className="ml-1" />
      </button>
      {isOpen && (
        <div className="absolute left-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
          <div className="py-1" role="menu" aria-orientation="vertical" aria-labelledby="options-menu">
            {items.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900"
                role="menuitem"
              >
                {item.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

const MobileNavLink = ({ href, label }) => (
  <Link
    href={href}
    className="block px-3 py-2 rounded-md text-base font-medium text-gray-800 hover:text-gray-900 hover:bg-gray-50"
  >
    {label}
  </Link>
)

const MobileDropdownLink = ({ label, items }) => {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex justify-between items-center w-full px-3 py-2 rounded-md text-base font-medium text-gray-800 hover:text-gray-900 hover:bg-gray-50"
      >
        {label}
        <ChevronDown
          size={16}
          className={`ml-1 transform transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}
        />
      </button>
      {isOpen && (
        <div className="pl-4">
          {items.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="block px-3 py-2 rounded-md text-base font-medium text-gray-800 hover:text-gray-900 hover:bg-gray-50"
            >
              {item.label}
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}

export default Header

